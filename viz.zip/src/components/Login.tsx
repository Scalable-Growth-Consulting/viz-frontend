
// This component is no longer needed - authentication is now handled by the Auth page
export default function Login() {
  return null;
}
